export class CreateUserDto {
    readonly name: string;
    readonly nin: string;
    readonly email: string;
}
