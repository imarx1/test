export class UpdateUserDto {
    readonly name: string;
    readonly nin: string;
    readonly email: string;
}
